Files: 

- Tausworthe-Generator.ipynb - the Python Jupyter notebook containing all code for the implementation of the Tausworthe generator, including the functions to create the generator, all graphs, and statistical tests. The code is commented out and includes some write-ups explaining statistical tests and conclusions, and is easy to follow. 

- project2_writeup.pdf - PDF report of the Tausworthe Generator, findings and conclusions. 